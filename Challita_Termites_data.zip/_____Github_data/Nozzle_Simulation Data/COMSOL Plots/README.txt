README
Supplementary Data Files

COMSOL Plots 
	t = timestep
	n = flow behavior index